-- Food Platform Seed Data
-- This script loads initial test data into the database

-- Insert test restaurants
INSERT IGNORE INTO restaurants (id, name, is_active) VALUES
(1, 'Pizza Palace', 1),
(2, 'Burger Hub', 1),
(3, 'Pasta Express', 1);

-- Insert menu items
INSERT IGNORE INTO menu_items (restaurant_id, name, base_price) VALUES
(1, 'Margherita Pizza', 250.00),
(1, 'Pepperoni Pizza', 300.00),
(2, 'Classic Burger', 150.00),
(2, 'Cheese Burger', 180.00),
(3, 'Spaghetti Carbonara', 220.00),
(3, 'Pasta Bolognese', 200.00);

-- Insert test user
INSERT IGNORE INTO users (id, email, is_active) VALUES
(1, 'customer@platform.internal', 1);
