#!/usr/bin/env python
"""
Database initialization and migration script
Ensures all required tables and columns exist in the food_platform database
"""

import os
import sys
import pymysql
from pathlib import Path
from decouple import config

def get_db_connection():
    """Establish a connection to the MySQL database"""
    try:
        conn = pymysql.connect(
            host=config("DB_HOST", default="localhost"),
            user=config("DB_USER", default="root"),
            password=config("DB_PASSWORD", default=""),
            port=config("DB_PORT", default=3306, cast=int),
            charset="utf8mb4"
        )
        return conn
    except Exception as e:
        print(f"❌ Failed to connect to MySQL: {e}")
        sys.exit(1)

def create_database():
    """Create the food_platform database if it doesn't exist"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        db_name = config("DB_NAME", default="food_platform")
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {db_name} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
        print(f"✅ Database '{db_name}' ready")
    except Exception as e:
        print(f"❌ Error creating database: {e}")
        sys.exit(1)
    finally:
        cursor.close()
        conn.close()

def run_init_sql():
    """Execute the initialization SQL scripts"""
    conn = pymysql.connect(
        host=config("DB_HOST", default="localhost"),
        user=config("DB_USER", default="root"),
        password=config("DB_PASSWORD", default=""),
        database=config("DB_NAME", default="food_platform"),
        port=config("DB_PORT", default=3306, cast=int),
        charset="utf8mb4"
    )
    
    cursor = conn.cursor()
    
    # Load schema.sql first (or fallback to init_database.sql)
    schema_file = Path(__file__).parent / "sql" / "schema.sql"
    if not schema_file.exists():
        schema_file = Path(__file__).parent / "init_database.sql"
    
    if not schema_file.exists():
        print(f"❌ SQL schema file not found: {schema_file}")
        sys.exit(1)
    
    # Execute schema
    print(f"   Loading schema from: {schema_file.name}")
    with open(schema_file, 'r') as f:
        sql_content = f.read()
    
    statements = sql_content.split(';')
    for statement in statements:
        statement = statement.strip()
        if statement and not statement.startswith('--'):
            try:
                cursor.execute(statement)
                conn.commit()
            except Exception as e:
                print(f"   ⚠️  SQL Error: {e}")
                conn.rollback()
    
    print("✅ Database schema initialized")
    
    # Load seed data if available
    seed_file = Path(__file__).parent / "sql" / "seed.sql"
    if seed_file.exists():
        print(f"   Loading seed data from: {seed_file.name}")
        with open(seed_file, 'r') as f:
            seed_content = f.read()
        
        statements = seed_content.split(';')
        for statement in statements:
            statement = statement.strip()
            if statement and not statement.startswith('--'):
                try:
                    cursor.execute(statement)
                    conn.commit()
                except Exception as e:
                    print(f"   ⚠️  Seed Error: {e}")
                    conn.rollback()
        
        print("✅ Seed data loaded")
    
    cursor.close()
    conn.close()

def verify_schema():
    """Verify that all required columns exist"""
    conn = pymysql.connect(
        host=config("DB_HOST", default="localhost"),
        user=config("DB_USER", default="root"),
        password=config("DB_PASSWORD", default=""),
        database=config("DB_NAME", default="food_platform"),
        port=config("DB_PORT", default=3306, cast=int),
        charset="utf8mb4"
    )
    
    cursor = conn.cursor()
    
    # Check for base_price column in menu_items
    try:
        cursor.execute("SELECT base_price FROM menu_items LIMIT 1")
        print("✅ menu_items.base_price column exists")
    except Exception as e:
        print(f"❌ Issue with menu_items.base_price: {e}")
        sys.exit(1)
    
    # Verify other critical tables
    tables = ['users', 'restaurants', 'menu_items', 'orders', 'order_items']
    cursor.execute("SHOW TABLES")
    existing_tables = {row[0] for row in cursor.fetchall()}
    
    for table in tables:
        if table in existing_tables:
            print(f"✅ Table '{table}' exists")
        else:
            print(f"❌ Table '{table}' missing")
    
    cursor.close()
    conn.close()

if __name__ == "__main__":
    print("🔧 Initializing Food Platform Database...\n")
    
    print("1️⃣  Creating database...")
    create_database()
    
    print("\n2️⃣  Running schema initialization...")
    run_init_sql()
    
    print("\n3️⃣  Verifying schema...")
    verify_schema()
    
    print("\n✨ Database setup complete!")
