#!/usr/bin/env python
"""
Debug script to check database state and fix schema issues
"""

import pymysql
from pathlib import Path
from decouple import config

def check_db_state():
    """Check the current state of the database"""
    try:
        conn = pymysql.connect(
            host=config("DB_HOST", default="localhost"),
            user=config("DB_USER", default="root"),
            password=config("DB_PASSWORD", default=""),
            database=config("DB_NAME", default="food_platform_db"),
            port=config("DB_PORT", default=3306, cast=int),
            charset="utf8mb4"
        )
        
        cursor = conn.cursor()
        
        print("\n=== DATABASE STATE CHECK ===\n")
        
        # Check tables
        cursor.execute("SHOW TABLES")
        tables = cursor.fetchall()
        print(f"Tables in database: {len(tables)}")
        for table in tables:
            print(f"  - {table[0]}")
        
        if not tables:
            print("\n❌ NO TABLES FOUND!")
            print("Schema was not created successfully")
            return False
        
        # Check menu_items structure
        print("\n--- menu_items structure ---")
        cursor.execute("DESCRIBE menu_items")
        columns = cursor.fetchall()
        
        has_base_price = False
        for col in columns:
            col_name = col[0]
            col_type = col[1]
            print(f"  {col_name}: {col_type}")
            if col_name == 'base_price':
                has_base_price = True
        
        if not has_base_price:
            print("\n❌ MISSING base_price COLUMN!")
            return False
        else:
            print("\n✅ base_price column exists")
        
        # Check data
        print("\n--- Data in tables ---")
        cursor.execute("SELECT COUNT(*) as cnt FROM restaurants")
        print(f"  restaurants: {cursor.fetchone()['cnt']} rows")
        
        cursor.execute("SELECT COUNT(*) as cnt FROM menu_items")
        print(f"  menu_items: {cursor.fetchone()['cnt']} rows")
        
        cursor.execute("SELECT COUNT(*) as cnt FROM users")
        print(f"  users: {cursor.fetchone()['cnt']} rows")
        
        cursor.execute("SELECT COUNT(*) as cnt FROM orders")
        print(f"  orders: {cursor.fetchone()['cnt']} rows")
        
        cursor.close()
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def recreate_schema(force=False):
    """Drop and recreate the schema
    
    Args:
        force (bool): If True, drop tables without confirmation. If False, only drop if tables are empty.
    """
    try:
        conn = pymysql.connect(
            host=config("DB_HOST", default="localhost"),
            user=config("DB_USER", default="root"),
            password=config("DB_PASSWORD", default=""),
            database=config("DB_NAME", default="food_platform_db"),
            port=config("DB_PORT", default=3306, cast=int),
            charset="utf8mb4"
        )
        
        cursor = conn.cursor()
        
        # Check if tables have data before dropping
        if not force:
            print("\n=== CHECKING FOR EXISTING DATA ===\n")
            
            check_tables = ['orders', 'restaurants', 'menu_items', 'users']
            has_data = False
            
            for table in check_tables:
                try:
                    cursor.execute(f"SELECT COUNT(*) FROM {table}")
                    count = cursor.fetchone()[0]
                    if count > 0:
                        print(f"⚠️  {table}: {count} rows (data found)")
                        has_data = True
                    else:
                        print(f"✓  {table}: empty")
                except:
                    print(f"✓  {table}: doesn't exist yet")
            
            if has_data:
                print("\n⚠️  CANNOT DROP TABLES: Existing data found!")
                print("   Use recreate_schema(force=True) to drop tables with data.")
                cursor.close()
                conn.close()
                return False
        
        print("\n=== DROPPING EXISTING TABLES ===\n")
        
        # Drop tables in reverse order of dependencies
        drop_tables = ['order_items', 'orders', 'menu_items', 'restaurants', 'users']
        for table in drop_tables:
            try:
                cursor.execute(f"DROP TABLE IF EXISTS {table}")
                conn.commit()
                print(f"✅ Dropped {table}")
            except Exception as e:
                print(f"⚠️  Could not drop {table}: {e}")
                conn.rollback()
        
        cursor.close()
        conn.close()
        
        print("\n=== CREATING NEW SCHEMA ===\n")
        
        # Read schema file
        schema_file = Path(__file__).parent / "sql" / "schema.sql"
        if not schema_file.exists():
            print(f"❌ Schema file not found: {schema_file}")
            return False
        
        with open(schema_file, 'r') as f:
            schema_content = f.read()
        
        # Execute schema
        conn = pymysql.connect(
            host=config("DB_HOST", default="localhost"),
            user=config("DB_USER", default="root"),
            password=config("DB_PASSWORD", default=""),
            database=config("DB_NAME", default="food_platform_db"),
            port=config("DB_PORT", default=3306, cast=int),
            charset="utf8mb4"
        )
        
        cursor = conn.cursor()
        
        statements = schema_content.split(';')
        for statement in statements:
            statement = statement.strip()
            if statement and not statement.startswith('--'):
                try:
                    cursor.execute(statement)
                    conn.commit()
                    print(f"✅ Executed: {statement[:60]}...")
                except Exception as e:
                    print(f"❌ Error: {e}")
                    print(f"   Statement: {statement[:100]}")
                    conn.rollback()
        
        # Load seed data
        print("\n=== LOADING SEED DATA ===\n")
        
        seed_file = Path(__file__).parent / "sql" / "seed.sql"
        if seed_file.exists():
            with open(seed_file, 'r') as f:
                seed_content = f.read()
            
            statements = seed_content.split(';')
            for statement in statements:
                statement = statement.strip()
                if statement and not statement.startswith('--'):
                    try:
                        cursor.execute(statement)
                        conn.commit()
                        print(f"✅ Executed seed: {statement[:60]}...")
                    except Exception as e:
                        print(f"⚠️  Seed error: {e}")
                        conn.rollback()
        
        cursor.close()
        conn.close()
        
        return True
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

if __name__ == "__main__":
    print("╔" + "="*58 + "╗")
    print("║" + "  DATABASE DEBUG & REPAIR TOOL".center(58) + "║")
    print("╚" + "="*58 + "╝")
    
    # Check current state
    is_ok = check_db_state()
    
    if not is_ok:
        print("\n❌ Database schema is incomplete or missing!")
        print("\n⚠️  ATTEMPTING TO REPAIR...\n")
        
        if recreate_schema():
            print("\n✅ Schema recreation completed!")
            print("\nVerifying...\n")
            check_db_state()
        else:
            print("\n❌ Failed to repair schema")
    else:
        print("\n✅ Database schema is OK!")
