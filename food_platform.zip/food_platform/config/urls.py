"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path
from apps.authapp.views import (LoginAPIView, 
    HomepagePortalView, 
    LoginPageView, 
    DashboardPageView,
    payload_dashboard,
    signup_page,
    logout_session)
from apps.restaurants.views import MenuListAPIView
from apps.orders.views import PlaceOrderAPIView, OrderHistoryAPIView
urlpatterns = [
    
    path('login/', LoginPageView.as_view(), name='web-login'),
    path('dashboard/', DashboardPageView.as_view(), name='web-dashboard'),
    path('logout/', logout_session, name='web-logout'),
    path('', HomepagePortalView.as_view(), name='system-portal'),
    path('api/auth/login/', LoginAPIView.as_view(), name='api-login'),
    path('api/restaurants/<int:restaurant_id>/menu/', MenuListAPIView.as_view(), name='menu-list'),
    path('api/orders/place/', PlaceOrderAPIView.as_view(), name='api_order_dispatch'),
    path('api/orders/history/', OrderHistoryAPIView.as_view(), name='api_order_records'),
    path("signup/", signup_page, name="signup"),
    path("payload/", payload_dashboard, name="payload"),
]