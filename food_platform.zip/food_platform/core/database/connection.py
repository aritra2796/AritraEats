import pymysql
from contextlib import contextmanager
from dbutils.pooled_db import PooledDB
from decouple import config

class DatabaseManager:
    _pool = None

    @classmethod
    def initialize_pool(cls):
        if cls._pool is None:
            cls._pool = PooledDB(
                creator=pymysql,
                mincached=5,
                maxcached=20,
                maxshared=0,
                maxconnections=50,
                blocking=True,
                host=config("DB_HOST"),
                user=config("DB_USER"),
                password=config("DB_PASSWORD"),
                database=config("DB_NAME"),
                port=config("DB_PORT", cast=int),
                charset="utf8mb4",
                cursorclass=pymysql.cursors.DictCursor
            )

    @classmethod
    @contextmanager
    def get_connection(cls):
        if cls._pool is None:
            cls.initialize_pool()
        conn = cls._pool.connection()
        try:
            yield conn
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()

@contextmanager
def execute_query(query: str, params: tuple = ()):
    with DatabaseManager.get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            conn.commit()
            yield cursor