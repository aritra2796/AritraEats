import jwt
from django.http import JsonResponse
from django.utils.deprecation import MiddlewareMixin
from core.database.connection import execute_query
from decouple import config

JWT_SECRET = config("JWT_SECRET")

class JWTAuthenticationMiddleware(MiddlewareMixin):
    def process_request(self, request):
        auth_header = request.headers.get('Authorization')
        request.user = None
        if auth_header and auth_header.startswith('Bearer '):
            token = auth_header.split(' ')[1]
            try:
                payload = jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
                user_id = payload.get('user_id')
                query = "SELECT id, email, role FROM users WHERE id = %s AND is_active = 1"
                with execute_query(query, (user_id,)) as cursor:
                    user = cursor.fetchone()
                    if user:
                        request.user = user
            except (jwt.ExpiredSignatureError, jwt.InvalidTokenError):
                return JsonResponse({'error': 'Authentication failed: Invalid or expired token'}, status=401)