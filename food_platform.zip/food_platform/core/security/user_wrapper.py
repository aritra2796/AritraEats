# Create file: core/security/user_wrapper.py

class AuthenticatedUser:
    """
    Wraps raw SQL dictionary outputs into an object compliant 
    with Django Rest Framework authentication requirements.
    """
    def __init__(self, user_dict: dict):
        self.id = user_dict.get("id")
        self.email = user_dict.get("email")
        self.role = user_dict.get("role")
        # Ensure truthy checks evaluate accurately against DB integers or booleans
        self.is_active = bool(user_dict.get("is_active", True))
        self.is_verified = bool(user_dict.get("is_verified", True))

    @property
    def is_authenticated(self):
        return True