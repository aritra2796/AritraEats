import hashlib
import secrets

class PasswordManager:
    @staticmethod
    def hash_password(password: str) -> str:
        iterations = 600000
        salt = secrets.token_hex(16)
        hashed_bytes = hashlib.pbkdf2_hmac(
            'sha256', password.encode('utf-8'), salt.encode('utf-8'), iterations
        )
        return f"pbkdf2_sha256${iterations}${salt}${hashed_bytes.hex()}"

    @staticmethod
    def verify_password(password: str, encoded_hash: str) -> bool:
        try:
            algorithm, iterations, salt, stored_hash = encoded_hash.split('$')
            if algorithm != 'pbkdf2_sha256':
                return False
            test_bytes = hashlib.pbkdf2_hmac(
                'sha256', password.encode('utf-8'), salt.encode('utf-8'), int(iterations)
            )
            return secrets.compare_digest(test_bytes.hex(), stored_hash)
        except ValueError:
            return False