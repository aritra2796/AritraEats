import jwt
from django.conf import settings
from decouple import config
from rest_framework.authentication import BaseAuthentication
from rest_framework.exceptions import AuthenticationFailed
from core.database.connection import execute_query
from core.security.user_wrapper import AuthenticatedUser

class JWTDatabaseAuthentication(BaseAuthentication):
    def authenticate(self, request):
        auth_header = request.headers.get("Authorization")
        if not auth_header:
            return None

        # Extract token cleanly from 'Bearer <token>' string
        try:
            if "Bearer " in auth_header:
                token = auth_header.split(" ")[1]
            else:
                token = auth_header
        except IndexError:
            raise AuthenticationFailed("Malformed authorization header structure.")

        # FALLBACK ENGINE: Force a shared fallback secret string if your .env isn't loading uniformly
        secret_key = config("JWT_SECRET", default="platform_engineering_secret_fallback_key_9912")

        try:
            # Decode the verified signature block matrix
            payload = jwt.decode(token, secret_key, algorithms=["HS256"])
            
            # Extract user index locator identifier
            user_id = payload.get("user_id") or payload.get("id")
            
            # Execute database user query matrix validation
            query = "SELECT id, email, is_active FROM users WHERE id = %s"
            with execute_query(query, (user_id,)) as cursor:
                user_row = cursor.fetchone()
                
            if not user_row:
                raise AuthenticationFailed("User context mapped to this signature node does not exist.")
            
            # Pack custom security profile object block context
            return (AuthenticatedUser(user_row), token)

        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed("Authentication failed: Invalid or expired token")
        except jwt.InvalidTokenError:
            raise AuthenticationFailed("Authentication failed: Malformed signature block")