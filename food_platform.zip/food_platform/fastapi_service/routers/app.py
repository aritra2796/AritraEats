from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr

from sqlalchemy import create_engine, Column, String, BigInteger
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import text

# ---------------- DB CONFIG ----------------
DATABASE_URL = "mysql+pymysql://root:root@127.0.0.1/food_platform_db"

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(bind=engine)

Base = declarative_base()

# ---------------- FASTAPI APP ----------------
app = FastAPI()

# ✅ CORS CONFIG
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:8000"],  # Django URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------- DB DEPENDENCY ----------------
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ---------------- USER MODEL ----------------
class DBUser(Base):
    __tablename__ = "users"

    id = Column(BigInteger, primary_key=True, index=True)
    email = Column(String(255), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    first_name = Column(String(100))
    last_name = Column(String(100))

# ---------------- CREATE TABLE (Optional) ----------------
# Uncomment only if table is NOT created already
Base.metadata.create_all(bind=engine)

# ---------------- PASSWORD HASH ----------------
def hash_password(password: str):
    return hashlib.sha256(password.encode()).hexdigest()

# ---------------- SCHEMA ----------------
class SignupSchema(BaseModel):
    email: EmailStr
    password: str
    first_name: str
    last_name: str

# ---------------- TEST ROUTE ----------------
@app.get("/test")
def test():
    return {"message": "Test route works ✅"}

# ---------------- SIGNUP API ----------------
@app.post("/api/auth/signup/")
def signup(data: SignupSchema, db: Session = Depends(get_db)):

    # ✅ Check existing user
    existing = db.query(DBUser).filter(DBUser.email == data.email).first()

    if existing:
        return {"status": "error", "detail": "User already exists"}

    # ✅ Create new user
    new_user = DBUser(
        email=data.email,
        password_hash=hash_password(data.password),
        first_name=data.first_name,
        last_name=data.last_name
    )

    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    return {
        "status": "success",
        "user_id": new_user.id
    }


from typing import List
from pydantic import BaseModel

class Item(BaseModel):
    name: str
    price: float

class Category(BaseModel):
    category_name: str
    items: List[Item]


class RestaurantInput(BaseModel):
    owner_id: int
    name: str
    description: str | None = None
    address: str
    latitude: float | None = None
    longitude: float | None = None


class PayloadSchema(BaseModel):
    restaurant: RestaurantInput
    menu: List[Category]



@app.post("/api/payload/ingest/")
def ingest_payload(data: PayloadSchema, db: Session = Depends(get_db)):

    # ✅ Step 1: Insert restaurant
    db.execute(
        text("""
        INSERT INTO restaurants (
            owner_id,
            name,
            description,
            address,
            latitude,
            longitude,
            status
        )
        VALUES (
            :owner_id,
            :name,
            :description,
            :address,
            :latitude,
            :longitude,
            'approved'
        )
        """),
        {
            "owner_id": data.restaurant.owner_id,
            "name": data.restaurant.name,
            "description": data.restaurant.description,
            "address": data.restaurant.address,
            "latitude": data.restaurant.latitude,
            "longitude": data.restaurant.longitude
        }
    )

    db.commit()

    # ✅ fetch new id
    restaurant_id = db.execute(text("SELECT LAST_INSERT_ID()")).scalar()

    total_items = 0

    # ✅ Step 2: Insert menu items
    for category in data.menu:
        for item in category.items:
            db.execute(
                text("""
                INSERT INTO menu_items (
                    restaurant_id,
                    name,
                    description,
                    price,
                    is_available
                )
                VALUES (
                    :restaurant_id,
                    :name,
                    :description,
                    :price,
                    1
                )
                """),
                {
                    "restaurant_id": restaurant_id,
                    "name": item.name,
                    "description": category.category_name,
                    "price": item.price
                }
            )

            total_items += 1

    db.commit()

    return {
        "status": "success",
        "restaurant_id": restaurant_id,
        "items_inserted": total_items
    }
