import logging
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from core.database.connection import DatabaseManager

logger = logging.getLogger(__name__)


class MenuListAPIView(APIView):
    def get(self, request, restaurant_id):
        try:
            with DatabaseManager.get_connection() as conn:
                with conn.cursor() as cursor:
                    query = "SELECT id, name, price, description FROM menu_items WHERE restaurant_id = %s AND is_deleted = 0"
                    cursor.execute(query, (restaurant_id,))
                    items = cursor.fetchall()
            
            # Convert to list of dicts for JSON response
            menu_items = []
            for item in items:
                menu_items.append({
                    "id": item['id'],
                    "name": item['name'],
                    "price": float(item['price']),
                    "description": item.get('description', '')
                })
            
            return Response(
                {"restaurant_id": restaurant_id, "menu": menu_items},
                status=status.HTTP_200_OK
            )
        except Exception as e:
            logger.error(f"Menu fetch error: {str(e)}", exc_info=True)
            return Response(
                {"error": "Failed to fetch menu items"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class RestaurantListAPIView(APIView):
    def get(self, request):
        try:
            with DatabaseManager.get_connection() as conn:
                with conn.cursor() as cursor:
                    query = "SELECT id, name FROM restaurants WHERE is_active = 1 AND deleted_at IS NULL"
                    cursor.execute(query)
                    restaurants = cursor.fetchall()
            
            restaurant_list = []
            for restaurant in restaurants:
                restaurant_list.append({
                    "id": restaurant['id'],
                    "name": restaurant['name']
                })
            
            return Response(
                {"restaurants": restaurant_list},
                status=status.HTTP_200_OK
            )
        except Exception as e:
            logger.error(f"Restaurant list fetch error: {str(e)}", exc_info=True)
            return Response(
                {"error": "Failed to fetch restaurants"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )