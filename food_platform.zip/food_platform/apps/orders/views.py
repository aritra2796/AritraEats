import os
import sys
import json
import logging
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from core.security.authentication import JWTDatabaseAuthentication
from core.database.connection import DatabaseManager
from datetime import datetime

logger = logging.getLogger(__name__)
FoodPlatformRawSQLAuth = JWTDatabaseAuthentication


class PlaceOrderAPIView(APIView):
    authentication_classes = [FoodPlatformRawSQLAuth]
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user
        restaurant_id = request.data.get("restaurant_id")
        items = request.data.get("items", [])
        
        lat = request.data.get("latitude", 28.4595)
        lng = request.data.get("longitude", 77.0266)

        if not restaurant_id or not items:
            return Response({"error": "Missing parameters: restaurant_id or items."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            with DatabaseManager.get_connection() as conn:
                with conn.cursor() as cursor:
                    subtotal = 0.00
                    calculated_items = []

                    # Fetch and validate menu items
                    for item in items:
                        cursor.execute("""
                            SELECT id, name, price 
                            FROM menu_items 
                            WHERE id = %s AND restaurant_id = %s AND is_deleted = 0
                        """, (item['menu_item_id'], restaurant_id))
                        item_row = cursor.fetchone()
                        
                        if not item_row:
                            return Response(
                                {"error": f"Item selection criteria error: Reference item key #{item['menu_item_id']} is not active."},
                                status=status.HTTP_404_NOT_FOUND
                            )
                        
                        qty = int(item['quantity'])
                        price = float(item_row['price'])
                        total_item_cost = price * qty
                        subtotal += total_item_cost
                        
                        calculated_items.append({
                            'id': item_row['id'],
                            'name': item_row['name'],
                            'qty': qty,
                            'price': price,
                            'total': total_item_cost
                        })

                    # Calculate totals
                    delivery_fee = 40.00
                    packaging_fee = 10.00
                    tax_amount = round(subtotal * 0.05, 2)
                    total_amount = subtotal + delivery_fee + packaging_fee + tax_amount
                    
                    # Insert order - net_amount is generated column, don't insert it
                    order_query = """
                        INSERT INTO orders (
                            customer_id, restaurant_id, total_amount, 
                            status, delivery_latitude, delivery_longitude
                        ) VALUES (%s, %s, %s, %s, %s, %s)
                    """
                    cursor.execute(order_query, (
                        user.id, restaurant_id, total_amount, 'placed',
                        float(lat), float(lng)
                    ))
                    conn.commit()
                    order_id = cursor.lastrowid
                    
                    # Generate and update order_number
                    order_number = f"ORD-{order_id}"
                    cursor.execute("UPDATE orders SET order_number = %s WHERE id = %s", (order_number, order_id))
                    conn.commit()

                    # Insert order items
                    for ci in calculated_items:
                        cursor.execute("""
                            INSERT INTO order_items (
                                order_id, menu_item_id, item_name, quantity, 
                                unit_price, total_price, addons_price
                            ) VALUES (%s, %s, %s, %s, %s, %s, %s)
                        """, (order_id, ci['id'], ci['name'], ci['qty'], ci['price'], ci['total'], 0.00))
                    
                    conn.commit()

            return Response({
                "message": "Order placed successfully.",
                "order_id": order_id,
                "order_number": order_number,
                "total_amount": total_amount
            }, status=status.HTTP_201_CREATED)

        except Exception as e:
            logger.error(f"Order placement error: {str(e)}", exc_info=True)
            return Response(
                {"error": f"Database transaction execution failure: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class OrderHistoryAPIView(APIView):
    authentication_classes = [FoodPlatformRawSQLAuth]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        try:
            with DatabaseManager.get_connection() as conn:
                with conn.cursor() as cursor:
                    # Query uses customer_id (not user_id) based on actual schema
                    query = """
                        SELECT id, order_number, restaurant_id, total_amount, status, created_at 
                        FROM orders 
                        WHERE customer_id = %s
                        ORDER BY created_at DESC
                    """
                    cursor.execute(query, (user.id,))
                    rows = cursor.fetchall()

            orders_history = []
            for row in rows:
                created_at = row['created_at']
                if isinstance(created_at, datetime):
                    created_at_str = created_at.strftime("%Y-%m-%d %H:%M:%S")
                else:
                    created_at_str = str(created_at) if created_at else "N/A"
                
                orders_history.append({
                    "id": row['id'],
                    "order_number": row['order_number'],
                    "restaurant_id": row['restaurant_id'],
                    "total_amount": float(row['total_amount']),
                    "status": row['status'],
                    "created_at": created_at_str
                })

            return Response({"orders": orders_history}, status=status.HTTP_200_OK)
        
        except Exception as e:
            logger.error(f"Order history fetch error: {str(e)}", exc_info=True)
            return Response(
                {"error": f"Failed to fetch orders: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )