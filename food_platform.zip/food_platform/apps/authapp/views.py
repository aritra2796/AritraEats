import datetime
import jwt
import time
import logging
from datetime import timezone
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from core.database.connection import DatabaseManager
from core.security.password import PasswordManager
from decouple import config
from django.views.generic import TemplateView
from django.shortcuts import redirect
from django.shortcuts import render


from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# ✅ CORS FIX (critical)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:8000"],  # Django origin
    allow_credentials=True,
    allow_methods=["*"],   # ✅ allows OPTIONS
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {"status": "API running"}
def payload_dashboard(request):
    return render(request, "payload/dashboard.html")

logger = logging.getLogger(__name__)
JWT_SECRET = config("JWT_SECRET", default="platform_engineering_secret_fallback_key_9912")


def signup_page(request):
    return render(request, "signup.html")

class LoginPageView(TemplateView):
    """Renders the client authentication interface wrapper."""
    template_name = "login.html"


class DashboardPageView(TemplateView):
    """Renders the main ordering and operations console page."""
    template_name = "dashboard.html"


def logout_session(request):
    """Clears any server state or redirects clean back to login."""
    return redirect('/login/')


class HomepagePortalView(TemplateView):
    """
    Production-Level Management Portal & API Directory.
    Runs real-time database pool telemetry checks using low-level diagnostics.
    """
    template_name = "homepage.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Calculate point-in-time Raw Database Telemetry metrics
        db_status = "OPERATIONAL"
        latency_ms = 0.0
        pool_metrics = {"allocated_connections": 0, "available_cache": 0}
        
        try:
            start_time = time.time()
            # Fetch internal stats directly from DBUtils Pool and MySQL thread indicators
            if DatabaseManager._pool:
                pool = DatabaseManager._pool
                pool_metrics["allocated_connections"] = pool._connections  # Current active connections
            
            with DatabaseManager.get_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("SELECT 1")
                    cursor.fetchone()
            
            latency_ms = round((time.time() - start_time) * 1000, 2)
        except Exception as e:
            db_status = f"DEGRADED: {str(e)}"

        # Inject infrastructure context variables safely into template engine
        context["system_metrics"] = {
            "gateway_status": "ONLINE",
            "database_status": db_status,
            "db_latency": f"{latency_ms}ms",
            "pool_active": pool_metrics["allocated_connections"],
            "environment": "Production Core Node"
        }
        return context


class LoginAPIView(APIView):
    def post(self, request):
        email = request.data.get("email")
        password = request.data.get("password")

        try:
            with DatabaseManager.get_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(
                        "SELECT id, email FROM users WHERE email = %s LIMIT 1",
                        (email,)
                    )
                    user_row = cursor.fetchone()
            
            if not user_row:
                return Response(
                    {"error": "Invalid credentials"},
                    status=status.HTTP_401_UNAUTHORIZED
                )
            
            user_id = user_row['id']
            
            # Build unified runtime token data payload matrix
            payload = {
                "user_id": user_id,
                "email": email,
                "exp": int(time.time()) + (60 * 60 * 24 * 7)  # Valid for 1 week
            }
            
            # Sign token signature block using standardized encryption algorithm
            token = jwt.encode(payload, JWT_SECRET, algorithm="HS256")
            
            return Response({"token": token}, status=status.HTTP_200_OK)
        
        except Exception as e:
            logger.error(f"Login error: {str(e)}", exc_info=True)
            return Response(
                {"error": "Authentication service error"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class SignUpAPIView(APIView):
    def post(self, request):
        email = request.data.get("email")
        password = request.data.get("password")

        if not email or not password:
            return Response(
                {"error": "Email and password are required"},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            with DatabaseManager.get_connection() as conn:
                with conn.cursor() as cursor:
                    # Check if user already exists
                    cursor.execute(
                        "SELECT id FROM users WHERE email = %s LIMIT 1",
                        (email,)
                    )
                    existing_user = cursor.fetchone()
                    
                    if existing_user:
                        return Response(
                            {"error": "User with this email already exists"},
                            status=status.HTTP_400_BAD_REQUEST
                        )
                    
                    # Create new user
                    cursor.execute(
                        "INSERT INTO users (email, is_active, created_at) VALUES (%s, %s, NOW())",
                        (email, True)
                    )
                    conn.commit()
                    user_id = cursor.lastrowid
            
            # Generate token for new user
            payload = {
                "user_id": user_id,
                "email": email,
                "exp": int(time.time()) + (60 * 60 * 24 * 7)
            }
            token = jwt.encode(payload, JWT_SECRET, algorithm="HS256")
            
            return Response(
                {"token": token, "user_id": user_id},
                status=status.HTTP_201_CREATED
            )
        
        except Exception as e:
            logger.error(f"Sign up error: {str(e)}", exc_info=True)
            return Response(
                {"error": "Registration failed"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

        return Response({"error": "Invalid profile security credentials"}, status=400)